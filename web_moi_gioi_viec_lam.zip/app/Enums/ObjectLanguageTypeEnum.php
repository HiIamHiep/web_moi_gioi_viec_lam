<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class ObjectLanguageTypeEnum extends Enum
{
    public const POST = '1';
}
