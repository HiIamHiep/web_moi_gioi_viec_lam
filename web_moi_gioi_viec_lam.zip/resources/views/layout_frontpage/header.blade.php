<div class="page-header header-filter header-small" data-parallax="true"
     style="background-image: url('https://png.pngtree.com/thumb_back/fh260/background/20230612/pngtree-windows-desktop-wallpaper-showing-a-green-grassy-area-image_2949017.jpg'); transform: translate3d(0px, 0px, 0px);">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="brand">
                    <h1 class="title">Welcome</h1>
                </div>
            </div>
        </div>
    </div>
</div>
