<?php

return array (
  'slug' => 'slug',
  'job_title' => 'job title',
  'city' => 'city',
  'district' => 'district',
  'level' => 'level',
  'ways_of_working' => 'ways of working',
  'link_jd' => 'link job description',
);
