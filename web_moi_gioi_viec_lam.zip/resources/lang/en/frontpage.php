<?php

return array (
  'title' => 'find what you need',
  'location' => 'location',
  'from_salary' => 'from',
  'to_salary' => 'up to',
  'applicant' => 'applicant',
  'hr' => 'hr',
  'not_available' => 'not available',
  'remote_only' => 'remote only',
  'office_only' => 'office only',
  'hybrid' => 'hybrid',
  'all' => 'all',
  'language' => 'language',
  'role' => 'role',
  'city' => 'city',
  'company' => 'company',
  'available' => 'available',
);
