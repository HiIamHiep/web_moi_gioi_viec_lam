<?php

return array (
  'slug' => 'slug',
  'job_title' => 'tiêu đề công việc',
  'city' => 'thành phố',
  'district' => 'quận/ huyện',
  'level' => 'cấp độ',
  'ways_of_working' => 'cách thức làm việc',
  'link_jd' => 'đường dẫn mô tả công việc',
);
