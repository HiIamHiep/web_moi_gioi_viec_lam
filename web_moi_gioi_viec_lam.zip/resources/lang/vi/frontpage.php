<?php

return array (
  'title' => 'đây là chỗ tìm kiếm',
  'location' => 'địa điểm',
  'from_salary' => 'Trên',
  'to_salary' => 'tới',
  'applicant' => 'ứng viên',
  'hr' => 'nhà tuyển dụng',
  'not_available' => 'đang đóng',
  'remote_only' => 'chỉ làm từ xa',
  'office_only' => 'chỉ làm tại văn phòng',
  'hybrid' => 'làm việc linh hoạt',
  'all' => 'tất cả',
  'language' => 'ngôn ngữ',
  'role' => 'vai trò',
  'city' => 'thành phố',
  'company' => 'công ty',
  'available' => 'đang mở',
);
